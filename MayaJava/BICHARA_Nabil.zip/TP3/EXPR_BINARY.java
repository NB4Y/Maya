abstract class EXPR_BINARY extends EXPR {
	protected EXPR left;
	protected EXPR right;
}