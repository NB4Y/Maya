class CST extends EXPR {
	int value;
	CST(int v) { 

	}

	int eval()
	{ return value; }
}
