abstract class EXPR {
	abstract int eval();
}