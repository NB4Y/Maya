public class Voiture extends Vehicule{

	public int calculTaxe()
	{return super.calculTaxe() + 4;}

}