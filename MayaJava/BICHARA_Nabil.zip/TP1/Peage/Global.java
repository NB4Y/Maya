public class Global {
	public static void main(String[] args) {
		Peage p = new Peage (50, 500);
		Voiture v1 = new Voiture();
		Voiture v2 = new Voiture();
		Voiture v3 = new Voiture();
		Voiture v4 = new Voiture();
		Voiture v5 = new Voiture();
		Voiture v6 = new Voiture();
		Voiture v7 = new Voiture();
		Voiture v8 = new Voiture();
		Voiture v9 = new Voiture();
		Camion c1 = new Camion(5, 3);
		Camion c2 = new Camion(3, 1);
		Camion c3 = new Camion(3, 1);
		Camion c4 = new Camion(5, 3);
		Camion c5 = new Camion(7, 4);
		Camion c6 = new Camion(5, 3);
		Camion c7 = new Camion(5, 3);
		Camion c8 = new Camion(3, 2);
		Camion c9 = new Camion(5, 3);

		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v1);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v2);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v3);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v4);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v5);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v6);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v7);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v8);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(v9);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c1);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c2);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c3);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c4);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c5);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c6);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c7);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c8);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

		p.Passage(c9);
		System.out.println("Vehicules: " + p.getNbreVehicule());
		System.out.println("Total Caisse: " + p.getTotalCaisse());
		System.out.println("");

	}
}	