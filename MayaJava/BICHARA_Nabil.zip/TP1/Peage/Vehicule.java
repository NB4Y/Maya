abstract class Vehicule {
	protected int calculTaxe()
	{return 0;}
}